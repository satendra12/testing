<?php
/**
 * @author Netbaseteam Team
 * @copyright Copyright (c) 2018 Cmsmart (http://www.cmsmart.net)
 * @package Netbaseteam_Onestepcheckout
 */


namespace Netbaseteam\Onestepcheckout\Block\Adminhtml\Field\Edit\Group\Row;

class Renderer extends \Netbaseteam\Onestepcheckout\Block\Adminhtml\Renderer\Template
{
    protected $_template = 'Netbaseteam_Onestepcheckout::widget/form/renderer/row.phtml';
}
