<?php
/**
 * Copyright © babtceh solutions  All rights reserved.
 * See COPYING.txt for license details.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Babtech_B2BCheckout', __DIR__);

